import java.sql.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    // Datos de conexión
    private static final String URL = "jdbc:mysql://localhost:3306/Tienda";
    private static final String USER = "root";
    private static final String PASSWORD = "Infor2022";

    // Logger para registrar eventos y errores
    private static final Logger LOGGER = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Conexión a la base de datos
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println("Conexión establecida.");

            boolean salir = false;
            while (!salir) {

                // Menú de opciones
                System.out.println("\nBienvenido a la Tienda");
                System.out.println("1. Insertar producto");
                System.out.println("2. Ver productos");
                System.out.println("3. Actualizar precio de producto");
                System.out.println("4. Eliminar producto");
                System.out.println("5. Salir");

                System.out.print("Elija una opción: ");
                int opcion = leerEntero(scanner);

                switch (opcion) {
                    case 1:
                        insertarProducto(conn, scanner);
                        break;
                    case 2:
                        leerProductos(conn);
                        break;
                    case 3:
                        actualizarPrecio(conn, scanner);
                        break;
                    case 4:
                        eliminarProducto(conn, scanner);
                        break;
                    case 5:
                        salir = true;
                        System.out.println("Saliendo...");
                        break;
                    default:
                        System.out.println("Opción no válida. Por favor, elija una opción correcta.");
                }
            }

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al conectar con la base de datos", e);
        } finally {
            scanner.close();
        }
    }

    // Método para insertar un producto
    public static void insertarProducto(Connection conn, Scanner scanner) {
        System.out.print("Ingrese el nombre del producto: ");
        String nombre = scanner.next();

        System.out.print("Ingrese el precio del producto: ");
        float precio = leerFloat(scanner);

        // Validar que el precio no sea negativo
        if (precio < 0) {
            System.out.println("Error: El precio no puede ser negativo.");
            return;
        }

        String sql = "INSERT INTO Productos (nombre, precio) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombre);
            stmt.setFloat(2, precio);
            stmt.executeUpdate();
            System.out.println("Producto insertado correctamente.");
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al insertar el producto", e);
        }
    }

    // Método para leer y mostrar los productos
    public static void leerProductos(Connection conn) {
        String sql = "SELECT * FROM Productos";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("Lista de productos:");
            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                float precio = rs.getFloat("precio");
                System.out.println("ID: " + id + ", Nombre: " + nombre + ", Precio: €" + precio);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al leer los productos", e);
        }
    }

    // Método para actualizar el precio de un producto
    public static void actualizarPrecio(Connection conn, Scanner scanner) {
        System.out.print("Ingrese el ID del producto a actualizar: ");
        int id = leerEntero(scanner);

        System.out.print("Ingrese el nuevo precio del producto: ");
        float nuevoPrecio = leerFloat(scanner);

        // Validar que el precio no sea negativo
        if (nuevoPrecio < 0) {
            System.out.println("Error: El precio no puede ser negativo.");
            return;
        }

        String sql = "UPDATE Productos SET precio = ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setFloat(1, nuevoPrecio);
            stmt.setInt(2, id);

            int filasActualizadas = stmt.executeUpdate();
            if (filasActualizadas > 0) {
                System.out.println("Producto con ID " + id + " actualizado a €" + nuevoPrecio);
            } else {
                System.out.println("No se encontró el producto con ID " + id);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al actualizar el producto", e);
        }
    }

    // Método para eliminar un producto
    public static void eliminarProducto(Connection conn, Scanner scanner) {
        System.out.print("Ingrese el ID del producto a eliminar: ");
        int id = leerEntero(scanner);

        String sql = "DELETE FROM Productos WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);

            int filasEliminadas = stmt.executeUpdate();
            if (filasEliminadas > 0) {
                System.out.println("Producto con ID " + id + " eliminado.");
            } else {
                System.out.println("No se encontró el producto con ID " + id);
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error al eliminar el producto", e);
        }
    }

    // Método para leer un entero de forma segura
    private static int leerEntero(Scanner scanner) {
        while (true) {
            try {
                return Integer.parseInt(scanner.next());
            } catch (NumberFormatException e) {
                System.out.print("Entrada no válida. Ingrese un número entero: ");
            }
        }
    }

    // Método para leer un float de forma segura
    private static float leerFloat(Scanner scanner) {
        while (true) {
            try {
                return Float.parseFloat(scanner.next());
            } catch (NumberFormatException e) {
                System.out.print("Entrada no válida. Ingrese un número decimal: ");
            }
        }
    }
}
