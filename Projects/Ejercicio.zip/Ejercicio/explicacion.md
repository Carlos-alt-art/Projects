# Ejercicio 6

1. Creo una conexión

<img src="src/imagen1.png">

2. Dentro de la conexión creo una base de datos Tienda, la selecciono y creo una tabla con los soguientes campos:
- id:  entero autoincrementable para identificar inequívocamente cada producto. Es la clave primaria y actúa como identificador único.
- nombre: nombre del producto, este guarda cadenas de texto hasta 255 caracteres y además este campo no puede ser nulo.
- precio: número cumero con decimales.

Este es el script SQL que se ve en pantalla:
```sql
CREATE DATABASE Tienda;

USE Tienda;

CREATE TABLE Productos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(255) NOT NULL,
  precio FLOAT
);
```


<img src="src/imagen2.png">

3. En el proyecto Java, dentro del archivo pom.xml pego la dependencia de JDBC, este me permite poder interactuar con la base da datos.

<img src="src/imagen3.png">

4. Dentro del archivo Main del proyecto Java defino los datos de la base de datos para realizar la conexion

<img src="src/imagen4.png">

5. Después escribo los métodos que tendra en programa

- Insertar
<img src="src/imagen5.png">

- Ver
<img src="src/imagen6.png">

- Actualizar 
<img src="src/imagen7.png">

- Eliminar
<img src="src/imagen8.png">


6. Añadí un Switch para decidir que método usaré
<img src="src/imagen9.png">



7. Finalmente añadí unos productos para probar la base de datos y su conxeión con el programa
<img src="src/imagen10.png">



