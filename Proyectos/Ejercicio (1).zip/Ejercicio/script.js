// Espera a que el contenido de la página se cargue completamente antes de ejecutar el script
// Esto asegura que todos los elementos del DOM estén disponibles

document.addEventListener("DOMContentLoaded", function () {

    // Obtiene la referencia al formulario en la página
    const form = document.querySelector("form");

    // Obtiene referencias a los elementos del formulario por su ID
    const nombreInput = document.getElementById("nombre");
    const edadInput = document.getElementById("edad");
    const correoInput = document.getElementById("correo");
    const comentariosInput = document.getElementById("comentarios");
    const textoError = document.getElementById("textoError");

    // Función para validar un campo específico usando una expresión regular
    function validarCampo(input, regex) {
        const valor = input.value.trim(); // Obtiene el valor del campo y elimina espacios en blanco
        if (regex.test(valor)) { // Si el valor cumple con la expresión regular
            input.classList.remove("error"); // Elimina la clase 'error' si estaba presente
            input.classList.add("success"); // Agrega la clase 'success' para indicar validación correcta
            return true; // Retorna true si la validación es exitosa
        } else {
            input.classList.remove("success"); // Elimina la clase 'success' si estaba presente
            input.classList.add("error"); // Agrega la clase 'error' para indicar que hay un error
            return false; // Retorna false si la validación falla
        }
    }

    // Función para validar todos los campos del formulario
    function validarFormulario() {
        let errores = []; // Se crea un array para almacenar los mensajes de error

        // Obtiene los valores de los campos eliminando espacios en blanco innecesarios
        const nombre = nombreInput.value.trim();
        const edad = edadInput.value.trim();
        const correo = correoInput.value.trim();
        const comentarios = comentariosInput.value.trim();

        // Expresión regular para validar nombres (solo letras y espacios, entre 3 y 20 caracteres)
        const regexNombre = /^[a-zA-ZÁÉÍÓÚáéíóúÑñ'´\-\s]{3,20}$/;
        if (!validarCampo(nombreInput, regexNombre)) {
            errores.push("El nombre debe tener entre 3 y 20 caracteres y solo puede contener letras y espacios.");
        }

        // Expresión regular para validar edades entre 1 y 120 años
        const regexEdad = /^(?:[1-9][0-9]?|1[01][0-9]|120)$/;
        if (!validarCampo(edadInput, regexEdad)) {
            errores.push("Por favor, ingresa una edad válida entre 1 y 120.");
        }

        // Expresión regular para validar direcciones de correo electrónico
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!validarCampo(correoInput, emailRegex)) {
            errores.push("El formato del correo electrónico no es válido.");
        }

        // Validación de comentarios (opcional, pero cambia el color si está vacío)
        if (comentarios.length > 0) {
            comentariosInput.classList.add("success"); // Si hay comentarios, se marca como válido
        } else {
            comentariosInput.classList.remove("success", "error"); // Si está vacío, se eliminan clases de validación
        }

        // Muestra los mensajes de error en el contenedor 'textoError', separados por saltos de línea
        textoError.innerHTML = errores.join("<br>");

        // Retorna 'true' si no hay errores, 'false' si hay errores
        return errores.length === 0;
    }

    // Eventos para validar los campos en tiempo real mientras el usuario escribe
    nombreInput.addEventListener("input", () => validarCampo(nombreInput, /^[a-zA-ZÁÉÍÓÚáéíóúÑñ'´\-\s]{3,20}$/));
    edadInput.addEventListener("input", () => validarCampo(edadInput, /^(?:[1-9][0-9]?|1[01][0-9]|120)$/));
    correoInput.addEventListener("input", () => validarCampo(correoInput, /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/));
    comentariosInput.addEventListener("input", validarFormulario);

    // Evento que se ejecuta cuando se intenta enviar el formulario
    form.addEventListener("submit", function (event) {
        if (!validarFormulario()) { // Si la validación falla
            event.preventDefault(); // Se cancela el envío del formulario para corregir errores
        } else {
            alert("Formulario enviado correctamente."); // Muestra una alerta si el formulario es válido
        }
    });

    // Al cargar la página, se eliminan las clases 'error' y 'success' de los inputs para limpiar su estado
    const inputs = [nombreInput, edadInput, correoInput, comentariosInput];
    inputs.forEach(input => {
        input.classList.remove("error", "success"); // Se asegura de que los campos estén en estado neutro al inicio
    });
});
